package main;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {

		// TODO Auto-generated method stub
		int freak = 60;
		/*
		 * 
		 */
		
		String fakeint = "int x=10;";
		
		String []sarr,k= {"22"};
		
		char c ='d';
		boolean x = true;
		byte bytes = 0b01;
		char []bytess =new char [ 9 ] ;
		int []arreglo1;
		char chars = 'c';
		
		int aaaa=10, dddddd, rrrrrrr[]={1,2};
		
		int x99=100;
		
		Object obs = new Object();
		Object obar[] = new Object[1];
		
		int []z, a= {1,2,3};
		int kk=10,b;
		int jkl     [] = {          1};
		int arr1 [ ] ;
		int arra []= new int[10];
		int [ ] arrc , arr2 , bbb= {20};
		int[ ]arrc1= {1,2} , arr21 , bbb1= {20},num= {1}, bo [];
		
		
		
		
		
		
	}

}
